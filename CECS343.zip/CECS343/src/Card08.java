import java.util.ArrayList;

import javax.swing.*;

public class Card08 extends Card{
	
	private ImageIcon img08;
	
	Card08(){
		img08 = new ImageIcon("images\\cardm08.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded) {
		if ((p.getX() == 330) && (p.getY() == (30 + index))) {
			Chip getPoint = new Chip(this, true);
			getPoint.craftDisable();
			getPoint.setVisible(true);
			if (getPoint.getText().equalsIgnoreCase("learning")) {
				p.setLearning(p.getLearningPoint() + 1);
			}
			else if(getPoint.getText().equalsIgnoreCase("integrity")) {
				p.setIntegrity(p.getIntegrityPoint() + 1);
			}
			
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img08 = another;
	}
	
	ImageIcon getCard() {
		return img08;
	}

	
}
