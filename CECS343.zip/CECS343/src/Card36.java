import javax.swing.*;

public class Card36 extends Card{
	
	private ImageIcon img36;
	
	Card36(){
		img36 = new ImageIcon("images\\cardm36.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img36 = another;
	}
	
	ImageIcon getCard() {
		return img36;
	}

	
}
