import java.util.ArrayList;

import javax.swing.*;

public class Card36 extends Card{
	
	private ImageIcon img36;
	
	Card36(){
		img36 = new ImageIcon("images\\cardm36.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card> playDeck, ArrayList<Card> discarded){
		//play in north or south, prereq = 2 integrity, get 3qp and chip choice
		//fail: discard 1 card
		if ((p.getX() == 150 && p.getY() == (800 + index)) && 
				(p.getX() == 600 && p.getY() == (800 + index)) &&
				p.getIntegrityPoint() >= 2) {
			p.setQuality(p.getQualityPoint() + 3);
			Chip getPoint = new Chip(this, true);
			getPoint.setVisible(true);
			if (getPoint.getText().equalsIgnoreCase("learning")) {
				p.setLearning(p.getLearningPoint() + 1);
			}
			else if(getPoint.getText().equalsIgnoreCase("integrity")) {
				p.setIntegrity(p.getIntegrityPoint() + 1);
			}
			else if(getPoint.getText().equalsIgnoreCase("craft")) {
				p.setCraft(p.getCraftPoint() + 1);
			}
			return true;
		}
		else {
			DiscardDisplay throwCard = new DiscardDisplay(this, true);
			throwCard.showDiscard(humanHand, discarded);
			throwCard.setVisible(true);
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Make a Friend for 3 Quality Points and a Chip of choice";
		else
			return "Make a Friend failed";
		
	}
	
	
	ImageIcon getCard() {
		return img36;
	}

	
}
