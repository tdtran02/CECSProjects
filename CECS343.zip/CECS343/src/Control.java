
public class Control extends ButtonController{
	public Control() {}
}
