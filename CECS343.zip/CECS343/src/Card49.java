import javax.swing.*;

public class Card49 extends Card{
	
	private ImageIcon img49;
	
	Card49(){
		img49 = new ImageIcon("images\\cardm49.png");
	}
	
	public boolean play(Player p, int index){
		//play in any room in ecs, prereq = 8 learning, 8 craft, 8 integrity, get 5 qp
		//fail: lose 2 qp, discard 1 game card
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img49 = another;
	}
	
	ImageIcon getCard() {
		return img49;
	}

	
}
