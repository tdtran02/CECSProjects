import javax.swing.*;

public class Card49 extends Card{
	
	private ImageIcon img49;
	
	Card49(){
		img49 = new ImageIcon("images\\cardm49.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img49 = another;
	}
	
	ImageIcon getCard() {
		return img49;
	}

	
}
