import java.util.ArrayList;

import javax.swing.*;

public class Card49 extends Card{
	
	private ImageIcon img49;
	
	Card49(){
		img49 = new ImageIcon("images\\cardm49.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){

		return true;
	}
	
	public String getCardName(boolean success) {
		return "";
	}
	
	ImageIcon getCard() {
		return img49;
	}

	
}
