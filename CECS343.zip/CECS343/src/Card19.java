import javax.swing.*;

public class Card19 extends Card{
	
	private ImageIcon img19;
	
	Card19(){
		img19 = new ImageIcon("images\\cardm19.png");
	}
	
	public boolean play(Player p, int index){
		//George allen field, 3 craft, get 5qp & 1 integrity. fail: student parking
	
		if (((p.getX() == 15) && (p.getY() == 30 + index)) && (p.getCraftPoint() >= 3)){
				p.setQuality(p.getQualityPoint() + 5);
				p.setIntegrity(p.getIntegrityPoint() + 1);
				
		}
		else {
			p.movePlayer("Student Parking", index);
			int pAt = p.getRoomList().compareMap("Student Parking");
			p.updateList(pAt);
		}
		
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img19 = another;
	}
	
	ImageIcon getCard() {
		return img19;
	}

	
}
