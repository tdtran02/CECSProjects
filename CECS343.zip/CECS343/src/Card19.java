import javax.swing.*;

public class Card19 extends Card{
	
	private ImageIcon img19;
	
	Card19(){
		img19 = new ImageIcon("images\\cardm19.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img19 = another;
	}
	
	ImageIcon getCard() {
		return img19;
	}

	
}
