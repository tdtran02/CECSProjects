import javax.swing.*;

public class Card16 extends Card{
	
	private ImageIcon img16;
	
	Card16(){
		img16 = new ImageIcon("images\\cardm16.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img16 = another;
	}
	
	ImageIcon getCard() {
		return img16;
	}

	
}
