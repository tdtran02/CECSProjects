import java.util.ArrayList;

import javax.swing.*;

public class Card16 extends Card{
	
	private ImageIcon img16;
	
	Card16(){
		img16 = new ImageIcon("images\\cardm16.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		if (((p.getX() == 15) && (p.getY() == (30 + index))) && (p.getIntegrityPoint() >= 4)) {
			p.setCraft(p.getCraftPoint() + 2);
		}
		else {
			p.movePlayer("Room Of Retirement", index);
			int pAt = p.getRoomList().compareMap("Room Of Retirement");
			p.updateList(pAt);
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img16 = another;
	}
	
	ImageIcon getCard() {
		return img16;
	}

	
}
