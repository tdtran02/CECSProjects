import javax.swing.*;

public class Card27 extends Card{
	
	private ImageIcon img27;
	
	Card27(){
		img27 = new ImageIcon("images\\cardm27.png");
	}
	
	public boolean play(Player p, int index){
		//eat room, need 3 craft, get 1 chip choice. Fail: lose 2qp
		if ((p.getX() == 750 && p.getY() == (650 + index)) && p.getCraftPoint() >= 3) {
			Chip getPoint = new Chip(this, true);
			getPoint.setVisible(true);
			if (getPoint.getText().equalsIgnoreCase("learning")) {
				p.setLearning(p.getLearningPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("craft")) {
				p.setCraft(p.getCraftPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("integrity")) {
				p.setIntegrity(p.getIntegrityPoint() + 1);
			}
		}
		else {
			p.setQuality(p.getQualityPoint() - 2);
		}
		return true;
	}
	
	void setCard(ImageIcon another) {
		img27 = another;
	}
	
	ImageIcon getCard() {
		return img27;
	}

	
}
