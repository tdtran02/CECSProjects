import javax.swing.*;

public class Card27 extends Card{
	
	private ImageIcon img27;
	
	Card27(){
		img27 = new ImageIcon("images\\cardm27.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img27 = another;
	}
	
	ImageIcon getCard() {
		return img27;
	}

	
}
