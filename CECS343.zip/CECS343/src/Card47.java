import java.util.ArrayList;

import javax.swing.*;

public class Card47 extends Card{
	
	private ImageIcon img47;
	
	Card47(){
		img47 = new ImageIcon("images\\cardm47.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//play in any ecs, prereq = 8 learning, 8 craft, 8 integrity, get 5qp
		//fail: lose 2 qp, discard 1 card
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img47 = another;
	}
	
	ImageIcon getCard() {
		return img47;
	}

	
}
