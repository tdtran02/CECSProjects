import javax.swing.*;

public class Card47 extends Card{
	
	private ImageIcon img47;
	
	Card47(){
		img47 = new ImageIcon("images\\cardm47.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img47 = another;
	}
	
	ImageIcon getCard() {
		return img47;
	}

	
}
