import javax.swing.*;

public class Card24 extends Card{
	
	private ImageIcon img24;
	
	Card24(){
		img24 = new ImageIcon("images\\cardm24.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img24 = another;
	}
	
	ImageIcon getCard() {
		return img24;
	}

	
}
