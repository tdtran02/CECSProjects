import java.util.ArrayList;

import javax.swing.*;

public class Card24 extends Card{
	
	private ImageIcon img24;
	
	Card24(){
		img24 = new ImageIcon("images\\cardm24.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//north or south hall, need 3 learning, 3 craft, 3 integrity, get 5qp and 1 card. Fail: discard 1 game card
		if (((p.getX() == 150 && p.getY() == (800 + index)) || 
				(p.getX() == 600 && p.getY() == (800 + index))) && (p.getLearningPoint() >= 3 && 
						p.getCraftPoint() >= 3 && p.getIntegrityPoint() >= 3)) {
			p.setQuality(p.getQualityPoint() + 5);
			//code to get 1 game card
		}
		else {
			//code to discard 1 card
		}
		return true;
	}
	
	void setCard(ImageIcon another) {
		img24 = another;
	}
	
	ImageIcon getCard() {
		return img24;
	}

	
}
