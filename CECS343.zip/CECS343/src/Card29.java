import java.util.ArrayList;

import javax.swing.*;

public class Card29 extends Card{
	
	private ImageIcon img29;
	
	Card29(){
		img29 = new ImageIcon("images\\cardm29.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		//George Allen Field, need 3 learning and 3 craft, get 5qp and 1 game card. Fail: Go to student parking
		if ((p.getX() == 15 && p.getY() == (30 + index)) && 
				(p.getLearningPoint() >= 3 && p.getCraftPoint() >= 3)){
			p.setQuality(p.getQualityPoint() + 5);
			hand.add(deck.get(0));
			deck.remove(0);
			return true;
		}
		else {
			p.movePlayer("Student Parking", index);
			int comp1At = p.getRoomList().compareMap("Student Parking");
			p.updateList(comp1At);
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Soccer Goalie for 5 Quality Points and 1 Game Card";
		else
			return "Soccer Goalie failed";
		
	}
	
	ImageIcon getCard() {
		return img29;
	}

	
}
