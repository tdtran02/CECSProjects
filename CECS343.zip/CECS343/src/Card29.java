import javax.swing.*;

public class Card29 extends Card{
	
	private ImageIcon img29;
	
	Card29(){
		img29 = new ImageIcon("images\\cardm29.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img29 = another;
	}
	
	ImageIcon getCard() {
		return img29;
	}

	
}
