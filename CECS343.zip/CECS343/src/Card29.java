import java.util.ArrayList;

import javax.swing.*;

public class Card29 extends Card{
	
	private ImageIcon img29;
	
	Card29(){
		img29 = new ImageIcon("images\\cardm29.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//George Allen Field, need 3 learning and 3 craft, get 5qp and 1 game card. Fail: Go to student parking
		if ((p.getX() == 15 && p.getY() == (30 + index)) && 
				(p.getLearningPoint() >= 3 && p.getCraftPoint() >= 3)){
			p.setQuality(p.getQualityPoint() + 5);
			//code for game card
		}
		else {
			p.movePlayer("Student Parking", index);
		}
		return true;
	}
	
	void setCard(ImageIcon another) {
		img29 = another;
	}
	
	ImageIcon getCard() {
		return img29;
	}

	
}
