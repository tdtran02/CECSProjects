import javax.swing.*;

public class Card40 extends Card{
	
	private ImageIcon img40;
	
	Card40(){
		img40 = new ImageIcon("images\\cardm40.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img40 = another;
	}
	
	ImageIcon getCard() {
		return img40;
	}

	
}
