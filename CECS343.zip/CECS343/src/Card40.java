import java.util.ArrayList;

import javax.swing.*;

public class Card40 extends Card{
	
	private ImageIcon img40;
	
	Card40(){
		img40 = new ImageIcon("images\\cardm40.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//play in either paking lot, prereq = 5 integrity, get 3qp and 1 card
		//lose 2qp
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img40 = another;
	}
	
	ImageIcon getCard() {
		return img40;
	}

	
}
