import java.util.ArrayList;

import javax.swing.*;

public class Card02 extends Card{
	
	private ImageIcon img02;
	
	Card02(){
		super();
		img02 = new ImageIcon("images\\cardm02.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded) {
		if ((p.getX() == 750) && (p.getY() == (1150 + index))) {
			p.setCraft(p.getCraftPoint() + 1);
		}
		
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img02 = another;
	}
	
	ImageIcon getCard() {
		return img02;
	}

	
}
