import javax.swing.*;

public class Card09 extends Card{
	
	private ImageIcon img09;
	
	Card09(){
		super();
		img09 = new ImageIcon("images\\cardm09.png");
	}
	
	public boolean play(Player p, int index) {
		//play in forbidden parking, get 1 learning chip, discard 1 card from hand, get 1 learning
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img09 = another;
	}
	
	ImageIcon getCard() {
		return img09;
	}

	
}
