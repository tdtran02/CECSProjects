import java.util.ArrayList;

import javax.swing.*;

public class Card09 extends Card{
	
	private ImageIcon img09;
	
	Card09(){
		super();
		img09 = new ImageIcon("images\\cardm09.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard) {
		//play in forbidden parking, get 1 learning chip, discard 1 card from hand, get 1 learning
		if (p.getX() == 750 && p.getY() == (350 + index)) {
			p.setLearning(p.getLearningPoint() + 1);
			if (hand.size() > 1) {
				DiscardDisplay throwCard = new DiscardDisplay(this, true);
				throwCard.showDiscard(hand, discard);
				throwCard.setVisible(true);
				if (throwCard.discardCard()) {
					p.setLearning(p.getLearningPoint() + 1);
				}
			}
			return true;
		}
		else
			return false;
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Parking Violation for 1 Learning Chip and another Learning Chip for 1 discard card";
		else
			return "Parking Violation failed";
		
	}
	
	ImageIcon getCard() {
		return img09;
	}

	
}
