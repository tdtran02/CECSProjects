import javax.swing.*;

public class Card28 extends Card{
	
	private ImageIcon img28;
	
	Card28(){
		img28 = new ImageIcon("images\\cardm28.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img28 = another;
	}
	
	ImageIcon getCard() {
		return img28;
	}

	
}
