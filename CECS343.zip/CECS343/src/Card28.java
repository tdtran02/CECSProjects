import java.util.ArrayList;

import javax.swing.*;

public class Card28 extends Card{
	
	private ImageIcon img28;
	
	Card28(){
		img28 = new ImageIcon("images\\cardm28.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//CECS conference, need 3 integrity, get chip choice. Fail: discard 1 game card
		if ((p.getX() == 900 && p.getY() == (650 + index)) && p.getIntegrityPoint() >= 3) {
			Chip getPoint = new Chip(this, true);
			getPoint.setVisible(true);
			if (getPoint.getText().equalsIgnoreCase("learning")) {
				p.setLearning(p.getLearningPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("craft")) {
				p.setCraft(p.getCraftPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("integrity")) {
				p.setIntegrity(p.getIntegrityPoint() + 1);
			}
		}
		else {
			//code for discard game card
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img28 = another;
	}
	
	ImageIcon getCard() {
		return img28;
	}

	
}
