import java.util.ArrayList;

import javax.swing.*;

public class Card28 extends Card{
	
	private ImageIcon img28;
	
	Card28(){
		img28 = new ImageIcon("images\\cardm28.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		//CECS conference, need 3 integrity, get chip choice. Fail: discard 1 game card
		if ((p.getX() == 900 && p.getY() == (650 + index)) && p.getIntegrityPoint() >= 3) {
			Chip getPoint = new Chip(this, true);
			getPoint.setVisible(true);
			if (getPoint.getText().equalsIgnoreCase("learning")) {
				p.setLearning(p.getLearningPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("craft")) {
				p.setCraft(p.getCraftPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("integrity")) {
				p.setIntegrity(p.getIntegrityPoint() + 1);
			}
			return true;
		}
		else {
			DiscardDisplay throwCard = new DiscardDisplay(this, true);
			throwCard.showDiscard(hand, discard);
			throwCard.setVisible(true);
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Professor Englert for Chip of choice";
		else
			return "Professor Englert failed";
		
	}
	ImageIcon getCard() {
		return img28;
	}

	
}
