import javax.swing.*;

public class Card0 extends Card{
	
	private ImageIcon img00;
	
	Card0(){
		super();
		img00 = new ImageIcon("images\\cardm00.png");
	}
	
	public boolean play(Player p) {
		if ((p.getX() == (450) && p.getY() == (650+80)) | (p.getX() == (600) && p.getY() == (960+80))){
			p.setIntegrity(p.getIntegrityPoint() + 1);		
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img00 = another;
	}
	
	ImageIcon getCard() {
		return img00;
	}

	
}
