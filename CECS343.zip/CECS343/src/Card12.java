import java.util.ArrayList;

import javax.swing.*;

public class Card12 extends Card{
	
	private ImageIcon img12;
	
	Card12(){
		img12 = new ImageIcon("images\\cardm12.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//play outside CECS, except forbidden parking get 1 craft, go to lactation lounge
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img12 = another;
	}
	
	ImageIcon getCard() {
		return img12;
	}

	
}
