import java.util.ArrayList;

import javax.swing.*;

public class Card12 extends Card{
	
	private ImageIcon img12;
	
	Card12(){
		img12 = new ImageIcon("images\\cardm12.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		//play outside CECS, except forbidden parking get 1 craft, go to lactation lounge
		if (((p.getX() < 150 || p.getX() > 900) && 
				(p.getY() < (650 + index) || p.getY() > (960 + index))) && 
				!(p.getX() == 750 && p.getY() == (350 + index))) {
			p.setCraft(p.getCraftPoint() + 1);
			p.movePlayer("Lactation Lounge", index);
			int comp1At = p.getRoomList().compareMap("Lactation Lounge");
			p.updateList(comp1At);
			return true;
		}
		else
			return false;
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Late for Class for 1 Craft Chip";
		else
			return "Late for Class failed";
		
	}
	
	ImageIcon getCard() {
		return img12;
	}

	
}
