import java.util.ArrayList;

import javax.swing.*;

public class Card50 extends Card{
	
	private ImageIcon img50;
	
	Card50(){
		img50 = new ImageIcon("images\\cardm50.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		
		return true;
	}
	
	public String getCardName(boolean success) {
		return "";
	}
	
	ImageIcon getCard() {
		return img50;
	}

	
}
