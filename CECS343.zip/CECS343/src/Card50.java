import javax.swing.*;

public class Card50 extends Card{
	
	private ImageIcon img50;
	
	Card50(){
		img50 = new ImageIcon("images\\cardm50.png");
	}
	
	public boolean play(Player p, int index){
		//play in student rec, get chip choice
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img50 = another;
	}
	
	ImageIcon getCard() {
		return img50;
	}

	
}
