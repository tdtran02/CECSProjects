import java.util.*;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public abstract class ButtonController extends JFrame {
	protected	String desc;
	
	public ButtonController() {
		desc = "unkown";		
	}
	
	public String getButtonName() {
		return desc;
		
	}
	public int action(Player human, int clickCounter) {return clickCounter;} // Move method
	public void action(StringBuilder text, ArrayList<Card> humanHand, ArrayList<Card> discarded,ArrayList<Card> sharedDeck,AreaText displayInfo, JTextArea textArea, Player human, Player name1, Player name2, int index) {} //Play Method
	public void action(ArrayList<Card> deckDraw, ArrayList<Card> humanHand, ArrayList<Card> discard) {} // Draw Method
}
