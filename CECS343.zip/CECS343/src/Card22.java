import java.util.ArrayList;

import javax.swing.*;

public class Card22 extends Card{
	
	private ImageIcon img22;
	
	Card22(){
		img22 = new ImageIcon("images\\cardm22.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		//japanese garden, need 3 learning, get 1 integrity and 1 craft. else go to lactation lounge
		if ((p.getX() == 330 && p.getY() == (30 + index)) && p.getLearningPoint() >= 3) {
			p.setIntegrity(p.getIntegrityPoint() + 1);
			p.setCraft(p.getCraftPoint() + 1);
			return true;
		}
		else {
			p.movePlayer("Lactation Lounge", index);
			int comp1At = p.getRoomList().compareMap("Lactation Lounge");
			p.updateList(comp1At);
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Fall in the Pond for 1 Integrity and 1 Craft Chip";
		else
			return "Fall in the Pond failed";
		
	}
	
	ImageIcon getCard() {
		return img22;
	}

	
}
