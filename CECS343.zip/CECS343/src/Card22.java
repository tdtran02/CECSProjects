import javax.swing.*;

public class Card22 extends Card{
	
	private ImageIcon img22;
	
	Card22(){
		img22 = new ImageIcon("images\\cardm22.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img22 = another;
	}
	
	ImageIcon getCard() {
		return img22;
	}

	
}
