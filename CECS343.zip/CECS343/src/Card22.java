import javax.swing.*;

public class Card22 extends Card{
	
	private ImageIcon img22;
	
	Card22(){
		img22 = new ImageIcon("images\\cardm22.png");
	}
	
	public boolean play(Player p, int index){
		//japanese garden, need 3 learning, get 1 integrity and 1 craft. else go to lactation lounge
		if ((p.getX() == 330 && p.getY() == (30 + index)) && p.getLearningPoint() >= 3) {
			p.setIntegrity(p.getIntegrityPoint() + 1);
			p.setCraft(p.getCraftPoint() + 1);
		}
		else {
			p.movePlayer("Lactation Lounge", index);
		}
		return true;
	}
	
	void setCard(ImageIcon another) {
		img22 = another;
	}
	
	ImageIcon getCard() {
		return img22;
	}

	
}
