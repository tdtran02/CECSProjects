import javax.swing.*;

public class Card00 extends Card{
	
	private ImageIcon img00;
	
	Card00(){
		super();
		img00 = new ImageIcon("images\\cardm00.png");
	}
	
	public boolean play(Player p, int index) {
		if ((p.getX() == (450) && p.getY() == (650 + index)) || (p.getX() == (600) && p.getY() == (960 + index))){
			p.setIntegrity(p.getIntegrityPoint() + 1);		
		}
		
		return true;
	}
	
	ImageIcon getCard() {
		return img00;
	}
}