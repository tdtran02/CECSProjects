
import java.util.ArrayList;

import javax.swing.*;

public class Card00 extends Card{
	
	private ImageIcon img00;
	
	Card00(){
		super();
		img00 = new ImageIcon("images\\cardm00.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded) {
		if ((p.getX() == (450) && p.getY() == (650 + index)) || (p.getX() == (600) && p.getY() == (960 + index))){
			p.setLearning(p.getLearningPoint() + 1);		
			return true;	
		}
		else {
			return false;	
		}
	}

	public String getCardName(Player p, int loc, ArrayList<Card> humanHand, ArrayList<Card>discarded) {
		//boolean success = play(p, loc, humanHand, discarded );
		
			return "CECS 100 for 1 Learning Chip";
		
	}
	ImageIcon getCard() {
		return img00;
	}

	
}