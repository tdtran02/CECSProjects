
import java.util.ArrayList;

public class Draw extends Control{
	ButtonController ctrl;
	
	
	public Draw(ButtonController main) {
		ctrl = main;
	
	}
	
	public String getButtonName() {
		return "Draw Card";
		
	}
	
	public void action(ArrayList<Card> deck, ArrayList<Card> drawHand, ArrayList<Card> discard) {
		if(deck.size() >= 1) {
			drawHand.add(deck.get(0));
			deck.remove(0);
		}
		else {
			
			for(int i = 0; i < discard.size(); i++) {
				deck.add(discard.get(0));
				discard.remove(0);	
			}
			drawHand.add(deck.get(0));
			deck.remove(0);
		}
		
	}
}
