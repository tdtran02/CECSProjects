import java.awt.Image;
import java.util.*;
import javax.swing.ImageIcon;

public class Hand{
	private ArrayList<Card> active;
	
	public Hand(ArrayList<Card> d){
		active = d;
		Collections.shuffle(active);
		//Collections.shuffle(deck);
	}
	
	public ImageIcon display(int displayIndex) {
		//Collections.shuffle(active);
		return active.get(displayIndex).getCard();
	}
	
	public Card addCard(){
		//Collections.shuffle(deck);
		Card playerCard = active.get(0);
		active.remove(0);
		return playerCard;
		
	}

}
