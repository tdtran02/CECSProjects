import java.awt.Image;
import java.util.*;
import javax.swing.ImageIcon;

public class Hand{
	private ArrayList<Card> active;
	
	public Hand(ArrayList<Card> d){
		active = d;
		Collections.shuffle(active);
	}
	
	public ImageIcon display(int displayIndex) {
		//Collections.shuffle(active);
		return active.get(displayIndex).getCard();
	}
	
	
	public ArrayList<Card> createHand(){
		ArrayList<Card> hand = new ArrayList<Card>();
		for(int i = 0; i < 5; i++) {
			hand.add(active.get(0));
			active.remove(0);
			
		}
		return hand;
	}

}
