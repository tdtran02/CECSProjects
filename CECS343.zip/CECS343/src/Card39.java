import javax.swing.*;

public class Card39 extends Card{
	
	private ImageIcon img39;
	
	Card39(){
		img39 = new ImageIcon("images\\cardm39.png");
	}
	
	public boolean play(Player p, int index){
		//play in room of retirement, prereq = 6 learning, 6 craft, 6 integrity, get 10qp
		//lose 1 card and leave card in room of retirement
		if ((p.getX() == 150 && p.getY() == (960 + index)) && (p.getLearningPoint() >= 6 &&
				p.getCraftPoint() >= 6 && p.getIntegrityPoint() >= 6)) {
			p.setQuality(p.getQualityPoint() + 10);
		}
		else {
			//code for lose card
			p.movePlayer("Forbidden Parking", index);
		}
		return true;
		
	}
	
	void setCard(ImageIcon another) {
		img39 = another;
	}
	
	ImageIcon getCard() {
		return img39;
	}

	
}
