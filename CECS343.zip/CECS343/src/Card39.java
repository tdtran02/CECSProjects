import javax.swing.*;

public class Card39 extends Card{
	
	private ImageIcon img39;
	
	Card39(){
		img39 = new ImageIcon("images\\cardm39.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img39 = another;
	}
	
	ImageIcon getCard() {
		return img39;
	}

	
}
