import java.util.ArrayList;

import javax.swing.*;

public class Card39 extends Card{
	
	private ImageIcon img39;
	
	Card39(){
		img39 = new ImageIcon("images\\cardm39.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card> playDeck, ArrayList<Card>discarded){
		//play in room of retirement, prereq = 6 learning, 6 craft, 6 integrity, get 10qp
		//lose 1 card and leave card in room of retirement
		if ((p.getX() == 150 && p.getY() == (960 + index)) && (p.getLearningPoint() >= 6 &&
				p.getCraftPoint() >= 6 && p.getIntegrityPoint() >= 6)) {
			p.setQuality(p.getQualityPoint() + 10);
			return true;
		}
		else {
			DiscardDisplay throwCard = new DiscardDisplay(this, true);
			throwCard.showDiscard(humanHand, discarded);
			throwCard.setVisible(true);
			p.movePlayer("Forbidden Parking", index);
			int comp1At = p.getRoomList().compareMap("Forbidden Parking");
			p.updateList(comp1At);
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Goodbye, Professor for 10 Quality Points";
		else
			return "Goodbye, Professor failed";
		
	}
	
	
	
	ImageIcon getCard() {
		return img39;
	}

	
}
