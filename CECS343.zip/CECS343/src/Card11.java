import java.util.ArrayList;
import java.util.Random;

import javax.swing.*;

public class Card11 extends Card{
	
	private ImageIcon img11;
	
	Card11(){
		img11 = new ImageIcon("images\\cardm11.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		if (((p.getX() == 15) && (p.getY() == (30 + index))) | ((p.getX() == 750) && (p.getY() == (650 + index)))) {
			if (index == 80) {
			Chip getPoint = new Chip(this, true);
			getPoint.integrityDisable();
			getPoint.setVisible(true);
			if (getPoint.getText().equalsIgnoreCase("learning")) {
				p.setLearning(p.getLearningPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("craft")) {
				p.setCraft(p.getCraftPoint() + 1);
			}
			}
			else {
				Random rand = new Random();
				int num = rand.nextInt(2);
				if (num == 0) {
					p.setLearning(p.getLearningPoint()+1);
				}
				else {
					p.setCraft(p.getCraftPoint() + 1);
				}
			}
			return true;
		}
		else {
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Buddy Up for 1 Learning Chip or 1 Craft Chip";
		else
			return "Buddy Up failed";
		
	}
	
	ImageIcon getCard() {
		return img11;
	}

	
}
