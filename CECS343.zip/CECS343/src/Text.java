import java.awt.event.*;
import java.awt.*;

import javax.swing.*;
public class Text extends JFrame{
	
	private JTextPane text;
	private Player comp1;
	private Player comp2;
	private Player human;
	
	Text(Player ai1, Player ai2, Player person){
		text = new JTextPane();
		comp1 = ai1;
		comp2 = ai2;
		human = person;
		display();
	}
	
	public void display() {
		text.setVisible(true);
		text.setFont(new Font("Courier New", 0, 14));
	
		StringBuilder point = new StringBuilder();
		point.append(String.format("%-10s %-10s %-7s %-11s %-16s\n", "", "Learning", 
						"Craft", "Integrity", "Quality Points")); //build string %- is right align number of spaces
		point.append(String.format("%-10s %-10s %-7s %-11s %-16s\n", comp1.getName(), 
				comp1.getLearningPoint(), comp1.getCraftPoint(), 
				comp1.getIntegrityPoint(), comp1.getQualityPoint()));
		point.append(String.format("%-10s %-10s %-7s %-11s %-16s\n", comp2.getName(), 
				comp2.getLearningPoint(), comp2.getCraftPoint(), 
				comp2.getIntegrityPoint(), comp2.getQualityPoint()));
		point.append(String.format("%-10s %-10s %-7s %-11s %-16s\n", human.getName(), 
				human.getLearningPoint(), human.getCraftPoint(), 
				human.getIntegrityPoint(), human.getQualityPoint()));
		
		point.append("\n");
		point.append(String.format("Card in deck: %-3s \tDiscards out of play: %-3s\n", 40, 0));
		point.append("You are " + human.getName() + " and you are in " + human.currentRoom());
		
		text.setText(point.toString());
	
	}
	 
	public JTextPane getText() {
		 return text;
	 }
	 
	
}
