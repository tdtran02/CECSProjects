import javax.swing.*;

public class Card20 extends Card{
	
	private ImageIcon img20;
	
	Card20(){
		img20 = new ImageIcon("images\\cardm20.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img20 = another;
	}
	
	ImageIcon getCard() {
		return img20;
	}

	
}
