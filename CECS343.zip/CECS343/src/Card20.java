import java.util.ArrayList;

import javax.swing.*;

public class Card20 extends Card{
	
	private ImageIcon img20;
	
	Card20(){
		img20 = new ImageIcon("images\\cardm20.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		//north or south hall, need 6 learning, get 5qp, else go to student parking
		if (((p.getX() == 150 && p.getY() == (800 + index)) || 
				(p.getX() == 600 && p.getY() == (800 + index))) && 
				(p.getLearningPoint() >= 6)) {
			p.setQuality(p.getQualityPoint() + 5);
			return true;
		}
		else {
			p.movePlayer("Student Parking", index);
			int comp1At = p.getRoomList().compareMap("Student Parking");
			p.updateList(comp1At);
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Make the Dean's List for 5 Quality Points";
		else
			return "Make the Dean's List failed";
		
	}
	
	ImageIcon getCard() {
		return img20;
	}

	
}
