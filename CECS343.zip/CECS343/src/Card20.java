import java.util.ArrayList;

import javax.swing.*;

public class Card20 extends Card{
	
	private ImageIcon img20;
	
	Card20(){
		img20 = new ImageIcon("images\\cardm20.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//north or south hall, need 6 learning, get 5qp, else go to student parking
		if (((p.getX() == 150 && p.getY() == (800 + index)) || 
				(p.getX() == 600 && p.getY() == (800 + index))) && 
				(p.getLearningPoint() >= 6)) {
			p.setQuality(p.getQualityPoint() + 5);
			
		}
		else {
			p.movePlayer("Student Parking", index);
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img20 = another;
	}
	
	ImageIcon getCard() {
		return img20;
	}

	
}
