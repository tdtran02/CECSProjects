import javax.swing.*;

public class Card30 extends Card{
	
	private ImageIcon img30;
	
	Card30(){
		img30 = new ImageIcon("images\\cardm30.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img30 = another;
	}
	
	ImageIcon getCard() {
		return img30;
	}

	
}
