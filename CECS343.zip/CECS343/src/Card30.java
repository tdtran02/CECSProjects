import java.util.ArrayList;

import javax.swing.*;

public class Card30 extends Card{
	
	private ImageIcon img30;
	
	Card30(){
		img30 = new ImageIcon("images\\cardm30.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		//play in library, prereq = 2 learning, get 1 learning and 1 game card
		//fail: lose 2 qp
		if ((p.getX() == 15 && p.getY() == (1150 + index)) &&
				p.getLearningPoint() >= 2) {
			p.setLearning(p.getLearningPoint() + 1);
			hand.add(deck.get(0));
			deck.remove(0);
			return true;
		}
		else {
			p.setQuality(p.getQualityPoint() - 2);
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Elective Class for 1 Learning Chip and 1 Game Card";
		else
			return "Elective Class failed";
		
	}
	
	ImageIcon getCard() {
		return img30;
	}

	
}
