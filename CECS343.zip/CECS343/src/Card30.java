import java.util.ArrayList;

import javax.swing.*;

public class Card30 extends Card{
	
	private ImageIcon img30;
	
	Card30(){
		img30 = new ImageIcon("images\\cardm30.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//play in library, prereq = 2 learning, get 1 learning and 1 game card
		//fail: lose 2 qp
		if ((p.getX() == 15 && p.getY() == (1150 + index)) &&
				p.getLearningPoint() >= 2) {
			p.setLearning(p.getLearningPoint() + 1);
			//code for getting game card
		}
		else {
			p.setQuality(p.getQualityPoint() - 2);
		}
		return true;
	}
	
	void setCard(ImageIcon another) {
		img30 = another;
	}
	
	ImageIcon getCard() {
		return img30;
	}

	
}
