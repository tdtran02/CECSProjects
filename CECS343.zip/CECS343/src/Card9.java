import javax.swing.*;

public class Card9 extends Card{
	
	private ImageIcon img09;
	
	Card9(){
		super();
		img09 = new ImageIcon("images\\cardm09.png");
	}
	
	public boolean play(Player p) {
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img09 = another;
	}
	
	ImageIcon getCard() {
		return img09;
	}

	
}
