import javax.swing.*;

public class Card5 extends Card{
	
	private ImageIcon img05;
	
	Card5(){
		super();
		img05 = new ImageIcon("images\\cardm05.png");
	}
	
	public boolean play(Player p) {
		if ((p.getX() == 600) && (p.getY() == (960 + 80))) {
			p.setCraft(p.getCraftPoint() + 1);
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img05 = another;
	}
	
	ImageIcon getCard() {
		return img05;
	}

	
}
