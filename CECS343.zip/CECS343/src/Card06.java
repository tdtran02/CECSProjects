import java.util.ArrayList;

import javax.swing.*;

public class Card06 extends Card{
	
	private ImageIcon img06;
	
	Card06(){
		img06 = new ImageIcon("images\\cardm06.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard) {
		if ((p.getX() == 330) && (p.getY() == (350 + index))) {
			p.setIntegrity(p.getIntegrityPoint() + 1);
			return true;
		}
		else
			return false;
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Exercising Mind and Body for 1 Integrity Chip";
		else
			return "Exercising Mind and Body failed";
		
	}
	ImageIcon getCard() {
		return img06;
	}

	
}
