import java.util.ArrayList;

import javax.swing.*;

public class Card06 extends Card{
	
	private ImageIcon img06;
	
	Card06(){
		img06 = new ImageIcon("images\\cardm06.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded) {
		if ((p.getX() == 330) && (p.getY() == (350 + index))) {
			p.setIntegrity(p.getIntegrityPoint() + 1);
		}
		return true;
	}
	
	void setCard(ImageIcon another) {
		img06 = another;
	}
	
	ImageIcon getCard() {
		return img06;
	}

	
}
