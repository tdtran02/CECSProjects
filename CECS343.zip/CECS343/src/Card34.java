import java.util.ArrayList;

import javax.swing.*;

public class Card34 extends Card{
	
	private ImageIcon img34;
	
	Card34(){
		img34 = new ImageIcon("images\\cardm34.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card> playDeck, ArrayList<Card> discarded){
		//play in any building not ECS, prereq = 6 craft, get 5 qp
		//fail: go to student parking
		if (((p.getX() == 330 && p.getY() == (200 + index)) || 
				(p.getX() == 330 && p.getY() == (350 + index)) ||
				(p.getX() == 15 && p.getY() == (1150 + index)) ||
				(p.getX() == 420 && p.getY() == (1150 + index)) ||
				(p.getX() == 750 && p.getY() == (1150 + index))) &&
				(p.getCraftPoint() >= 6)) {
			p.setQuality(p.getQualityPoint() + 5);
			return true;
		}
		else {
			p.movePlayer("Student Parking", index);
			int comp1At = p.getRoomList().compareMap("Student Parking");
			p.updateList(comp1At);
			return false;
		}
	}
	
	public String getCardName(boolean success) {		
		if (success)
			return "CHEM 111 for 5 Quality Points";
		else
			return "CHEM 111 failed";
		
	}
	
	
	ImageIcon getCard() {
		return img34;
	}

	
}
