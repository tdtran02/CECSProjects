import javax.swing.*;

public class Card34 extends Card{
	
	private ImageIcon img34;
	
	Card34(){
		img34 = new ImageIcon("images\\cardm34.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img34 = another;
	}
	
	ImageIcon getCard() {
		return img34;
	}

	
}
