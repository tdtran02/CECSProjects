import javax.swing.*;
import java.util.*;

public abstract class Card extends JFrame{
	
	private ImageIcon cardImg;
	
	Card(){
		cardImg = new ImageIcon();
	}

	public abstract boolean play(Player person, int index, ArrayList<Card> humanHand, ArrayList<Card> discarded);
	
	void setCard(ImageIcon set) {
		cardImg = set;
	}
	
	ImageIcon getCard() {
		return cardImg;
	}
	
	public static ArrayList<Card> addFresh(){
		ArrayList<Card> list = new ArrayList<Card>();
		list.add(new Card00());
		list.add(new Card01());
		list.add(new Card02());
		list.add(new Card03());
		list.add(new Card04());
		list.add(new Card05());
		list.add(new Card06());
		list.add(new Card07());
		list.add(new Card08());
		list.add(new Card09());
		list.add(new Card10());
		list.add(new Card11());
		list.add(new Card12());
		list.add(new Card13());
		list.add(new Card14());
		list.add(new Card15());
		list.add(new Card16());
		list.add(new Card17());
		list.add(new Card18());
		list.add(new Card19());
		list.add(new Card20());
		list.add(new Card21());
		list.add(new Card22());
		list.add(new Card23());
		list.add(new Card24());
		list.add(new Card25());
		list.add(new Card26());
		list.add(new Card27());
		list.add(new Card28());
		list.add(new Card29());
		list.add(new Card30());
		list.add(new Card31());
		list.add(new Card32());
		list.add(new Card33());
		list.add(new Card34());
		list.add(new Card35());
		list.add(new Card36());
		list.add(new Card37());
		list.add(new Card38());
		list.add(new Card39());
		
		return list;
	}
	
	public static ArrayList<Card> addSoph(){
		ArrayList<Card> soph = new ArrayList<Card>();
		soph.add(new Card40());
		soph.add(new Card41());
		soph.add(new Card42());
		soph.add(new Card43());
		soph.add(new Card44());
		soph.add(new Card45());
		soph.add(new Card46());
		soph.add(new Card47());
		soph.add(new Card48());
		soph.add(new Card49());
		soph.add(new Card50());
		soph.add(new Card51());

		return soph;
	}
	public abstract String getCardName(Player human, int location, ArrayList<Card> hand, ArrayList<Card>deck);
}
