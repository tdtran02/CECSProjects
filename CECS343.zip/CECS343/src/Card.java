import javax.swing.*;

public abstract class Card extends JFrame{
	
	private ImageIcon cardImg;
	
	Card(){
		cardImg = new ImageIcon();
	}

	public abstract boolean play(Player person);
	
	void setCard(ImageIcon set) {
		cardImg = set;
	}
	
	ImageIcon getCard() {
		return cardImg;
	}
	
	
	
}
