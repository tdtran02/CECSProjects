import java.util.ArrayList;

import javax.swing.*;

public class Card38 extends Card{
	
	private ImageIcon img38;
	
	Card38(){
		img38 = new ImageIcon("images\\cardm38.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card> playDeck, ArrayList<Card> discarded){
		//play in stduent parking, get in craft chip, teleport to lactation lounge
		if (p.getX() == 700 && p.getY() == (30 + index))
		{
			p.setCraft(p.getCraftPoint() + 1);
			p.movePlayer("Lactation Lounge", index);
			int comp1At = p.getRoomList().compareMap("Lactation Lounge");
			p.updateList(comp1At);
			return true;
		}
		else
			return false;
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Student Parking for 1 Craft Chip";
		else
			return "Student Parking failed";
		
	}
	
	
	ImageIcon getCard() {
		return img38;
	}

	
}
