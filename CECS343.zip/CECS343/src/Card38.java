import javax.swing.*;

public class Card38 extends Card{
	
	private ImageIcon img38;
	
	Card38(){
		img38 = new ImageIcon("images\\cardm38.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img38 = another;
	}
	
	ImageIcon getCard() {
		return img38;
	}

	
}
