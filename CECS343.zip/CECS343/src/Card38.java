import java.util.ArrayList;

import javax.swing.*;

public class Card38 extends Card{
	
	private ImageIcon img38;
	
	Card38(){
		img38 = new ImageIcon("images\\cardm38.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//play in stduent parking, get in craft chip, teleport to lactation lounge
		if (p.getX() == 700 && p.getY() == (30 + index))
		{
			p.setCraft(p.getCraftPoint() + 1);
			p.movePlayer("Lactation Lounge", index);
		}
		return true;
	}
	
	void setCard(ImageIcon another) {
		img38 = another;
	}
	
	ImageIcon getCard() {
		return img38;
	}

	
}
