import java.util.ArrayList;

import javax.swing.*;

public class Card48 extends Card{
	
	private ImageIcon img48;
	
	Card48(){
		img48 = new ImageIcon("images\\cardm48.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		
		return true;
	}
	
	public String getCardName(boolean success) {
		return "";
	}
	ImageIcon getCard() {
		return img48;
	}

	
}
