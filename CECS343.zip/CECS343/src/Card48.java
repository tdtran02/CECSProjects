import javax.swing.*;

public class Card48 extends Card{
	
	private ImageIcon img48;
	
	Card48(){
		img48 = new ImageIcon("images\\cardm48.png");
	}
	
	public boolean play(Player p,int index){
		//play in eat room or japanese garden, prereq = 6 learning, get 5qp or chip choice
		//fail: lose 3qp
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img48 = another;
	}
	
	ImageIcon getCard() {
		return img48;
	}

	
}
