import java.util.ArrayList;

import javax.swing.*;

public class Card23 extends Card{
	
	private ImageIcon img23;
	
	Card23(){
		img23 = new ImageIcon("images\\cardm23.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//computer lab, need 4 integrity, get 3qp and chip of choice. else discard 1 game card
		if ((p.getX() == 150 && p.getY() == (650 + index)) && p.getIntegrityPoint() >= 4) {
			p.setQuality(p.getQualityPoint() + 3);
			
			Chip getPoint = new Chip(this, true);
			getPoint.setVisible(true);
			if (getPoint.getText().equalsIgnoreCase("learning")) {
				p.setLearning(p.getLearningPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("craft")) {
				p.setCraft(p.getCraftPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("integrity")) {
				p.setIntegrity(p.getIntegrityPoint() + 1);
			}
		}
		else {
			//code to discard card
		}
		return true;
	}
	
	void setCard(ImageIcon another) {
		img23 = another;
	}
	
	ImageIcon getCard() {
		return img23;
	}

	
}
