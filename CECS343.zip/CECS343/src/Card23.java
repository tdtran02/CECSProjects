import javax.swing.*;

public class Card23 extends Card{
	
	private ImageIcon img23;
	
	Card23(){
		img23 = new ImageIcon("images\\cardm23.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img23 = another;
	}
	
	ImageIcon getCard() {
		return img23;
	}

	
}
