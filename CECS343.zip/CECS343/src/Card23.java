import java.util.ArrayList;

import javax.swing.*;

public class Card23 extends Card{
	
	private ImageIcon img23;
	
	Card23(){
		img23 = new ImageIcon("images\\cardm23.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		//computer lab, need 4 integrity, get 3qp and chip of choice. else discard 1 game card
		if ((p.getX() == 150 && p.getY() == (650 + index)) && p.getIntegrityPoint() >= 4) {
			p.setQuality(p.getQualityPoint() + 3);
			
			Chip getPoint = new Chip(this, true);
			getPoint.setVisible(true);
			if (getPoint.getText().equalsIgnoreCase("learning")) {
				p.setLearning(p.getLearningPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("craft")) {
				p.setCraft(p.getCraftPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("integrity")) {
				p.setIntegrity(p.getIntegrityPoint() + 1);
			}
			return true;
		}
		else {
			DiscardDisplay throwCard = new DiscardDisplay(this, true);
			throwCard.showDiscard(hand, discard);
			throwCard.setVisible(true);
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "A New Laptop for 3 Quality Points and 1 Chip of choice";
		else
			return "A New Laptop failed";
		
	}
	
	ImageIcon getCard() {
		return img23;
	}

	
}
