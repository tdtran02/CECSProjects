import javax.swing.*;

public class Card44 extends Card{
	
	private ImageIcon img44;
	
	Card44(){
		img44 = new ImageIcon("images\\cardm44.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}	
	
	void setCard(ImageIcon another) {
		img44 = another;
	}
	
	ImageIcon getCard() {
		return img44;
	}

	
}
