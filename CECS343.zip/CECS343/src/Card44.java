import java.util.ArrayList;

import javax.swing.*;

public class Card44 extends Card{
	
	private ImageIcon img44;
	
	Card44(){
		img44 = new ImageIcon("images\\cardm44.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//play in la5 or library, prereq = 7 integrity, get 5qp and chip choice
		//fail: discard 1 card
		return true;
	}	
	
	void setCard(ImageIcon another) {
		img44 = another;
	}
	
	ImageIcon getCard() {
		return img44;
	}

	
}
