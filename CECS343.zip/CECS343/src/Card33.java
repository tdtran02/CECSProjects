import javax.swing.*;

public class Card33 extends Card{
	
	private ImageIcon img33;
	
	Card33(){
		img33 = new ImageIcon("images\\cardm33.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img33 = another;
	}
	
	ImageIcon getCard() {
		return img33;
	}

	
}
