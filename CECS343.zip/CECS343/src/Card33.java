import java.util.ArrayList;
import java.util.Random;

import javax.swing.*;

public class Card33 extends Card{
	
	private ImageIcon img33;
	
	Card33(){
		img33 = new ImageIcon("images\\cardm33.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card> playDeck, ArrayList<Card> discarded){
		//play in any building not ECS, prereq = 4 integrity, get 4qp and chip choice
		//fail: discard 1 card
		if (((p.getX() == 330 && p.getY() == (200 + index)) || 
				(p.getX() == 330 && p.getY() == (350 + index)) ||
				(p.getX() == 15 && p.getY() == (1150 + index)) ||
				(p.getX() == 420 && p.getY() == (1150 + index)) ||
				(p.getX() == 750 && p.getY() == (1150 + index))) &&
				(p.getCraftPoint() >= 4)) {
			p.setQuality(p.getQualityPoint() + 4);
			
			if (index == 80) {
			Chip getPoint = new Chip(this, true);
			getPoint.setVisible(true);
			if (getPoint.getText().equalsIgnoreCase("learning")) {
				p.setLearning(p.getLearningPoint() + 1);
			}
			else if(getPoint.getText().equalsIgnoreCase("integrity")) {
				p.setIntegrity(p.getIntegrityPoint() + 1);
			}
			else if(getPoint.getText().equalsIgnoreCase("craft")) {
				p.setCraft(p.getCraftPoint() + 1);
			}
			}
			else {
				Random rand = new Random();
				int num = rand.nextInt(3);
				if (num == 0) {
					p.setLearning(p.getLearningPoint()+1);
				}
				else if (num == 1) {
					p.setIntegrity(p.getIntegrityPoint()+1);
				}
				else {
					p.setCraft(p.getCraftPoint() + 1);
				}
			}
			return true;
		}
		else {
			if (index == 80) {
			DiscardDisplay throwCard = new DiscardDisplay(this, true);
			throwCard.showDiscard(humanHand, discarded);
			throwCard.setVisible(true);
			}
			else {
				if (humanHand.size() >1) {
					discarded.add(humanHand.get(1));
					humanHand.remove(1);
				}
			}
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Oral Communication for 4 Quality Points and 1 Chip of choice";
		else
			return "Oral Communication failed";
		
	}
	
	
	ImageIcon getCard() {
		return img33;
	}

	
}
