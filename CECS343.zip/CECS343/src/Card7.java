import javax.swing.ImageIcon;

public class Card7 extends Card{
	
	private ImageIcon img07;
	
	Card7(){
		img07 = new ImageIcon("images\\cardm07.png");
	}
	
	public boolean play(Player p) {
		if ((p.getX() == 450) && (p.getY() == (960 + 80))) {
			p.setIntegrity(p.getIntegrityPoint() + 1);
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img07 = another;
	}
	
	ImageIcon getCard() {
		return img07;
	}

	
}
