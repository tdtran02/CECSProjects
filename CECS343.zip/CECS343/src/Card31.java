import java.util.ArrayList;

import javax.swing.*;

public class Card31 extends Card{
	
	private ImageIcon img31;
	
	Card31(){
		img31 = new ImageIcon("images\\cardm31.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discarded){
		//play in any room in ECS, except lactation lounge, prereq = 3 learning, get 5qp and 2 card
		//fail: lose 5qp and got to lactation lounge
		if (((p.getX() >= 150 && p.getX() <= 900) && 
				(p.getY() >= 650  && p.getY() <= (960 + index)) &&
				!(p.getX() == 900 && p.getY() == (960 + index))) && 
				p.getLearningPoint() >= 3) {
			p.setQuality(p.getQualityPoint() + 5);
			hand.add(deck.get(0));
			hand.add(deck.get(1));
			deck.remove(0);
			deck.remove(1);
			return true;
		}
		else {
			p.setQuality(p.getQualityPoint() - 5);
			p.movePlayer("Lactation Lounge", index);
			int comp1At = p.getRoomList().compareMap("Lactation Lounge");
			p.updateList(comp1At);
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Professor Hoffman for 5 Quality Points and 2 Game Cards";
		else
			return "Professor Hoffman failed";
		
	}
	
	ImageIcon getCard() {
		return img31;
	}

	
}
