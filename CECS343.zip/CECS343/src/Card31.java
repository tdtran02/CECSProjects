import javax.swing.*;

public class Card31 extends Card{
	
	private ImageIcon img31;
	
	Card31(){
		img31 = new ImageIcon("images\\cardm31.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img31 = another;
	}
	
	ImageIcon getCard() {
		return img31;
	}

	
}
