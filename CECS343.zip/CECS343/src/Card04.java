import java.util.ArrayList;

import javax.swing.ImageIcon;

public class Card04 extends Card{
	
	private ImageIcon img04;
	
	Card04(){
		super();
		img04 = new ImageIcon("images\\cardm04.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded) {
		if ((p.getX() == 450) && (p.getY() == (650 + index))) {
			p.setLearning(p.getLearningPoint() + 1);
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img04 = another;
	}
	
	ImageIcon getCard() {
		return img04;
	}

	
}
