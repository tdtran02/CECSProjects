import java.util.ArrayList;

import javax.swing.ImageIcon;

public class Card04 extends Card{
	
	private ImageIcon img04;
	
	Card04(){
		super();
		img04 = new ImageIcon("images\\cardm04.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard) {
		if ((p.getX() == 450) && (p.getY() == (650 + index))) {
			p.setLearning(p.getLearningPoint() + 1);
			return true;
		}
		else
			return false;
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Professor Murgolo's CECS 174 Class for 1 Learning Chip";
		else
			return "Professor Murgolo's CECS 174 Class failed";
		
	}
	
	ImageIcon getCard() {
		return img04;
	}

	
}
