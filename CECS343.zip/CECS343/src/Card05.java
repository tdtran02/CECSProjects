import java.util.ArrayList;

import javax.swing.*;

public class Card05 extends Card{
	
	private ImageIcon img05;
	
	Card05(){
		super();
		img05 = new ImageIcon("images\\cardm05.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard) {
		if ((p.getX() == 600) && (p.getY() == (960 + index))) {
			p.setCraft(p.getCraftPoint() + 1);
			return true;
		}
		else
			return false;
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "CECS 100 for 1 Craft Chip";
		else
			return "CECS 100 failed";
		
	}
	
	ImageIcon getCard() {
		return img05;
	}

	
}
