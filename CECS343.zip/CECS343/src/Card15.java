import javax.swing.*;

public class Card15 extends Card{
	
	private ImageIcon img15;
	
	Card15(){
		img15 = new ImageIcon("images\\cardm15.png");
	}
	
	public boolean play(Player p, int index){
		if (((p.getX() == 600) && p.getY() == (960 + index)) && (p.getCraftPoint() >= 3)) {
			p.setQuality(p.getQualityPoint() + 5);
		}
		else {
			p.setQuality(p.getQualityPoint() - 3);
				//code for lose game card
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img15 = another;
	}
	
	ImageIcon getCard() {
		return img15;
	}

	
}
