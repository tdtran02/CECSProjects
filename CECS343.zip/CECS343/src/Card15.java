import javax.swing.*;

public class Card15 extends Card{
	
	private ImageIcon img15;
	
	Card15(){
		img15 = new ImageIcon("images\\cardm15.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img15 = another;
	}
	
	ImageIcon getCard() {
		return img15;
	}

	
}
