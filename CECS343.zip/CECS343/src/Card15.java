import java.util.ArrayList;

import javax.swing.*;

public class Card15 extends Card{
	
	private ImageIcon img15;
	
	Card15(){
		img15 = new ImageIcon("images\\cardm15.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		if (((p.getX() == 600) && p.getY() == (960 + index)) && (p.getCraftPoint() >= 3)) {
			p.setQuality(p.getQualityPoint() + 5);
			return true;
		}
		else {
			p.setQuality(p.getQualityPoint() - 3);
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Physics 151 for 5 Quality Points";
		else
			return "Physics 151 failed";
		
	}
	
	ImageIcon getCard() {
		return img15;
	}

	
}
