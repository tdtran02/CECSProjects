import java.util.ArrayList;

import javax.swing.*;

public class Card42 extends Card{
	
	private ImageIcon img42;
	
	Card42(){
		img42 = new ImageIcon("images\\cardm42.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//play in ecs 302, 308, or lab, prereq = 8 craft, get 1 learing, 1 craft, 1 integrity
		//fail: lose 3qp and discard 1 game card;
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img42 = another;
	}
	
	ImageIcon getCard() {
		return img42;
	}

	
}
