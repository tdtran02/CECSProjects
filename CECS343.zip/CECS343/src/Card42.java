import java.util.ArrayList;

import javax.swing.*;

public class Card42 extends Card{
	
	private ImageIcon img42;
	
	Card42(){
		img42 = new ImageIcon("images\\cardm42.png");
	}
	
public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		
		return true;
	}
	
	public String getCardName(boolean success) {
		return "";
	}
	
	ImageIcon getCard() {
		return img42;
	}

	
}
