import java.awt.event.ActionEvent;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Move extends Control {

	ButtonController ctrl;
	
	public Move(ButtonController main) {
		ctrl = main;
	}
	
	public String getButtonName() {
		return "Move"; 
		
	}
	
	public int action(Player human, int clickCounter) {
		if (human.getList().getSelectedValue() != null) {
			 String humanRoom = (String)human.getList().getSelectedValue();
			 int labelAt = human.getRoomList().compareMap(humanRoom);
			 human.movePlayer(humanRoom, 80);
			 human.updateList(labelAt);
			 clickCounter++;
		
		}
		 else {
			 JFrame frame = new JFrame();
			 JOptionPane.showMessageDialog(frame, "No room selected");
		 }
		return clickCounter;
	}

}