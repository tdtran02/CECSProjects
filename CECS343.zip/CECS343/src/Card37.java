import java.util.ArrayList;

import javax.swing.*;

public class Card37 extends Card{
	
	private ImageIcon img37;
	
	Card37(){
		img37 = new ImageIcon("images\\cardm37.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card> playDeck, ArrayList<Card> discarded){
		//play outside ECS, get 1 craft and go to lactation lounge
		if ((p.getX() < 150 || p.getX() > 900) && 
				(p.getY() < (650 + index) || p.getY() > (960 + index))) {
			p.setCraft(p.getCraftPoint() + 1);
			p.movePlayer("Lactation Lounge", index);
			int comp1At = p.getRoomList().compareMap("Lactation Lounge");
			p.updateList(comp1At);
			return true;
		}
		else
			return false;
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Enjoying Nature for 1 Craft Chip";
		else
			return "Enjoying Nature failed";
		
	}
	
	
	ImageIcon getCard() {
		return img37;
	}

	
}
