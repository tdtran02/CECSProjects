import javax.swing.*;

public class Card37 extends Card{
	
	private ImageIcon img37;
	
	Card37(){
		img37 = new ImageIcon("images\\cardm37.png");
	}
	
	public boolean play(Player p, int index){
		//play outside ECS, get 1 craft and go to lactation lounge
		if ((p.getX() < 150 || p.getX() > 900) && 
				(p.getY() < (650 + index) || p.getY() > (960 + index))) {
			p.setCraft(p.getCraftPoint() + 1);
			p.movePlayer("Lactation Lounge", index);
		}
		return true;
	}
	
	void setCard(ImageIcon another) {
		img37 = another;
	}
	
	ImageIcon getCard() {
		return img37;
	}

	
}
