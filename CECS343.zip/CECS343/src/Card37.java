import javax.swing.*;

public class Card37 extends Card{
	
	private ImageIcon img37;
	
	Card37(){
		img37 = new ImageIcon("images\\cardm37.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img37 = another;
	}
	
	ImageIcon getCard() {
		return img37;
	}

	
}
