import java.util.ArrayList;

import javax.swing.*;

public class Card03 extends Card{
	
	private ImageIcon img03;
	
	Card03(){
		super();
		img03 = new ImageIcon("images\\cardm03.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded) {
		if ((p.getX() == 15) && (p.getY() == (1150 + index))) {
			p.setLearning(p.getLearningPoint() + 1);
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img03 = another;
	}
	
	ImageIcon getCard() {
		return img03;
	}

	
}
