import java.util.ArrayList;

import javax.swing.*;

public class Card03 extends Card{
	
	private ImageIcon img03;
	
	Card03(){
		super();
		img03 = new ImageIcon("images\\cardm03.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard) {
		if ((p.getX() == 15) && (p.getY() == (1150 + index))) {
			p.setLearning(p.getLearningPoint() + 1);
			return true;
		}
		else
			return false;
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Research Compilers for 1 Learning Chip";
		else
			return "Research Compilers failed";
		
	}
	
	ImageIcon getCard() {
		return img03;
	}

	
}
