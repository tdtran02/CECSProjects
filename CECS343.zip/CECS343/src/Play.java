
import java.util.*;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Play extends Control {
	ButtonController ctrl;
	
	public Play(ButtonController main) {
		ctrl = main;
	}
	
	public String getButtonName() {
		return "Play Card"; 
		
	}
	
	public void action(StringBuilder newString, ArrayList<Card> humanHand, ArrayList<Card> discarded, ArrayList<Card> sharedDeck,AreaText displayInfo, JTextArea textArea, Player human, Player name1, Player name2, int index) {
		boolean success = false;
		if(sharedDeck.size() >= 1) {
			displayInfo.setPlayer(human);
			//Human Play move
				success = humanHand.get(index).play(human, 80, humanHand, sharedDeck, discarded);
				newString.insert(0,displayInfo.displayText(success, humanHand, index));//80, sharedDeck, discarded));
				discarded.add(humanHand.get(index));
				humanHand.remove(index);
				
					// Computer 1 Play move
				Random play1 = new Random();
				if (play1.nextInt(2) == 0) {
				displayInfo.setPlayer(name1);
				 Random rand1 = new Random();
				 int number1 = rand1.nextInt(name1.getList().getModel().getSize()-1);
				 String comp1Room = ((String)name1.getList().getModel().getElementAt(number1));
				 int comp1At = name1.getRoomList().compareMap(comp1Room);
				 name1.movePlayer(comp1Room, 0);
				 name1.updateList(comp1At);
					 success = sharedDeck.get(0).play(name1, 0, sharedDeck, sharedDeck, discarded);
				 	newString.insert(0,displayInfo.displayText(success, sharedDeck, 0));
				 	discarded.add(sharedDeck.get(0));
				 	sharedDeck.remove(0); 
				}	
				 
				 //Computer 2 Play move
				Random play2 = new Random();
				if (play2.nextInt(2) == 1) {
				 displayInfo.setPlayer(name2);
				 Random rand2 = new Random();
				 int number2 = rand2.nextInt(name2.getList().getModel().getSize()-1);
				 String comp2Room = ((String)name2.getList().getModel().getElementAt(number2));
				 int comp2At = name2.getRoomList().compareMap(comp2Room);
				 name2.movePlayer(comp2Room, 40);
				 name2.updateList(comp2At); 
				 success = sharedDeck.get(0).play(name2, 40, sharedDeck, sharedDeck, discarded);
				 newString.insert(0,displayInfo.displayText(success, sharedDeck, 0));
				 discarded.add(sharedDeck.get(0));
				 sharedDeck.remove(0);
				}
				 
			}
			else {
				//Declaring constant size of discard deck; Re-adding discard deck to Main deck
				int sizeofDiscard = discarded.size();
				for(int i = 0; i < sizeofDiscard; i++) {
					sharedDeck.add(discarded.get(0));
					discarded.remove(0);
					
				}
				
			}
		
		textArea.setText(newString.toString());
		
		}
		
	

}
