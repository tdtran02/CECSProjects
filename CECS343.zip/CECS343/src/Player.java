import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.util.*;

public class Player{
	private JLabel player;
	private Location coor = new Location();
	private JList map = new JList();
	private Room roomList;
	private int craftPoint;
	private int learnPoint;
	private int integrityPoint;
	private int qualityPoint;
	private Hand playHand;
	
	public Player() {
		player = new JLabel();
		coor.addLocation();
		roomList = new Room();
		roomList.addList("pathways.txt");
		updateList(0);
		
		//System.out.println(coor.loc());
	}
	
	public void setPlayer(int index) {
		String[] name = new String[] {"Matt", "Sophia", "Steve"};
		player.setForeground(new Color(255, 51, 0));
		player.setFont(new Font("Tahoma", 1, 27));
		player.setText(name[index]);
	}
	public String getName() {
		return player.getText();
	}
	
	public JLabel getPlayer() {
		return player;
	}

	public void setPlayerLoc(int x, int y) {
		player.setBounds(x, y, 100, 50);
	}
	
	public void movePlayer(String roomLocation, int addY) {
		player.setLocation(coor.getLocX(roomLocation), coor.getLocY(roomLocation)+ addY);
		
	}
	
	public int getX() {
		return player.getX();
	}
	
	public int getY() {
		return player.getY();
	}
	
	public int getCraftPoint() {
		return craftPoint;
	}
	
	public int getLearningPoint() {
		return learnPoint;
	}
	
	public int getIntegrityPoint() {
		return integrityPoint;
	}
	
	public int getQualityPoint() {
		return qualityPoint;
	}
	
	public void setCraft(int craft) {
		craftPoint = craft;
	}
	
	public void setLearning(int learn) {
		learnPoint = learn;
	}
	
	public void setIntegrity(int integrity) {
		integrityPoint = integrity;
	}
	
	public void setQuality(int quality) {
		qualityPoint = quality;
	}
	
	public Room getRoomList() {
		return roomList;
	}
	
	 public void updateList(int index) {
		 String[] in = roomList.getList(index).split("\\|+");
	 	    String[] strings = new String[in.length];
	 	    
	 	    for (int i = 1; i < in.length; i++) {
	 	    	strings[i - 1] = in[i];
	 	    }
		    map.setModel(new AbstractListModel<String>() {
		    
		    public int getSize(){return strings.length;}
		    public String getElementAt(int i) {return strings[i];}
		    });
		    
	 }
	 
	 public JList getList() {
		 return map;
	 }
	 
	 public String currentRoom() {
		 Location currentCoor = new Location();
		 currentCoor.addLocation();
		 int x = player.getX();
		 int y = player.getY() - 80;
		 for (int i = 0; i < currentCoor.length(); i++) {
			 String [] location = currentCoor.loc().get(i).split(",+");
				 int locX = Integer.parseInt(location[1]);
				 int locY = Integer.parseInt(location[2]);
				 if (x == locX && y == locY) {
					return location[0];
				 }
		 }
		 return null;
	 }
}
