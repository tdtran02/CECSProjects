import java.util.ArrayList;
import java.util.Random;

import javax.swing.*;

public class Card35 extends Card{
	
	private ImageIcon img35;
	
	Card35(){
		img35 = new ImageIcon("images\\cardm35.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card> playDeck, ArrayList<Card> discarded){
		//play in comp lab, prereq = 2 craft and 3 integrity, get 3qp and chip choice
		//fail: lose 1qp
		if ((p.getX() == 150 && p.getY() == (650 + index)) &&
				(p.getCraftPoint() >= 2 && p.getIntegrityPoint() >= 3)) {
			p.setQuality(p.getQualityPoint() + 3);
			if (index == 80) {
				Chip getPoint = new Chip(this, true);
				getPoint.setVisible(true);
				if (getPoint.getText().equalsIgnoreCase("learning")) {
					p.setLearning(p.getLearningPoint() + 1);
				}
				else if(getPoint.getText().equalsIgnoreCase("integrity")) {
					p.setIntegrity(p.getIntegrityPoint() + 1);
				}
				else if(getPoint.getText().equalsIgnoreCase("craft")) {
					p.setCraft(p.getCraftPoint() + 1);
				}
			}
			else {
					Random rand = new Random();
					int num = rand.nextInt(3);
					if (num == 0) {
						p.setLearning(p.getLearningPoint()+1);
					}
					else if (num == 1) {
						p.setIntegrity(p.getIntegrityPoint()+1);
					}
					else {
						p.setCraft(p.getCraftPoint() + 1);
					}
			}
		
			return true;
		}
		else {
			p.setQuality(p.getQualityPoint() - 1);
			return false;
		}
	}

	public String getCardName(boolean success) {
		if (success)
			return "Learning Linux for 3 Quality Points and a Chip of choice";
		else
			return "Learning Linux failed";
		
	}
	
	
	ImageIcon getCard() {
		return img35;
	}

	
}
