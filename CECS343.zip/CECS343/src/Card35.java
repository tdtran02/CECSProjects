import javax.swing.*;

public class Card35 extends Card{
	
	private ImageIcon img35;
	
	Card35(){
		img35 = new ImageIcon("images\\cardm35.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}

	void setCard(ImageIcon another) {
		img35 = another;
	}
	
	ImageIcon getCard() {
		return img35;
	}

	
}
