import javax.swing.*;

public class Card25 extends Card{
	
	private ImageIcon img25;
	
	Card25(){
		img25 = new ImageIcon("images\\cardm25.png");
	}
	
	public boolean play(Player p, int index){
		//lactation lounge, need 2 learning, get 5qp and chip choice. Fail: discard 1 game card
		if ((p.getX() == 900 && p.getY() == (960 + index)) && p.getLearningPoint() >= 2) {
			p.setQuality(p.getQualityPoint() + 5);
			
			Chip getPoint = new Chip(this, true);
			getPoint.setVisible(true);
			if (getPoint.getText().equalsIgnoreCase("learning")) {
				p.setLearning(p.getLearningPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("craft")) {
				p.setCraft(p.getCraftPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("integrity")) {
				p.setIntegrity(p.getIntegrityPoint() + 1);
			}
		}
		else {
			//code to discard card
		}
		return true;
	}
	
	void setCard(ImageIcon another) {
		img25 = another;
	}
	
	ImageIcon getCard() {
		return img25;
	}

	
}
