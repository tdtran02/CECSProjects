import java.util.ArrayList;

import javax.swing.*;

public class Card25 extends Card{
	
	private ImageIcon img25;
	
	Card25(){
		img25 = new ImageIcon("images\\cardm25.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		//lactation lounge, need 2 learning, get 5qp and chip choice. Fail: discard 1 game card
		if ((p.getX() == 900 && p.getY() == (960 + index)) && p.getLearningPoint() >= 2) {
			p.setQuality(p.getQualityPoint() + 5);
			
			Chip getPoint = new Chip(this, true);
			getPoint.setVisible(true);
			if (getPoint.getText().equalsIgnoreCase("learning")) {
				p.setLearning(p.getLearningPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("craft")) {
				p.setCraft(p.getCraftPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("integrity")) {
				p.setIntegrity(p.getIntegrityPoint() + 1);
			}
			return true;
		}
		else {
			DiscardDisplay throwCard = new DiscardDisplay(this, true);
			throwCard.showDiscard(hand, discard);
			throwCard.setVisible(true);
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Program Crashes for 5 Quality Points and Chip of choice";
		else
			return "Program Crashes failed";
		
	}
	
	ImageIcon getCard() {
		return img25;
	}

	
}
