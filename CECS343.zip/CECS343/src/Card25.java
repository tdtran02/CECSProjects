import javax.swing.*;

public class Card25 extends Card{
	
	private ImageIcon img25;
	
	Card25(){
		img25 = new ImageIcon("images\\cardm25.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img25 = another;
	}
	
	ImageIcon getCard() {
		return img25;
	}

	
}
