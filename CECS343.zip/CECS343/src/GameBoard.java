import java.awt.*;
import java.awt.List;
import java.awt.event.*;

import javax.imageio.*;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;
import java.util.*;


public class GameBoard extends JFrame{
	private ImageIcon image;
	private JLabel label;
	private JLabel cardImg;
	private Player name1;
	private Player name2;
	private Player human;
	private JPanel panel1;
	private JPanel panel2;
	private JScrollPane scroll1;
	private JScrollPane scroll2;
	private JScrollPane scroll3;
	private Text textField;
	private JTextArea textArea;
	private JButton button1;
	private JButton button2;
	private JButton button3;
	private Room mapList;
	private Chip showChip;
	private Hand show;
	ButtonController main;
	private int count = 0;
	private int clickCounter = 0;
	private ArrayList<Card> deck = Card.addFresh();
	private ArrayList<Card> playerHand = new ArrayList<Card>();
	private ArrayList<Card> discardDeck = new ArrayList<Card>();
	private AreaText display = new AreaText();
	public GameBoard() {
		//System.out.print(deck.get(0).getCard());
		boardComponent();
		
	}
	
	private void boardComponent() {
	    label = new JLabel();
	    cardImg = new JLabel();
	    name1 = new Player();
	    name2 = new Player();
	    human = new Player();
	    panel1 = new JPanel();
	    panel2 = new JPanel();
		scroll1 = new JScrollPane();
		scroll2 = new JScrollPane();
		scroll3 = new JScrollPane();
	    button1 = new JButton();
	    button2 = new JButton();
	    button3 = new JButton();
	    
	    //deck = Card.addFresh();
	    
	    show = new Hand(deck);
	    playerHand = show.createHand();
	    
	    textArea = new JTextArea();
	       
	    Random rand = new Random();
		int number = rand.nextInt(3);
		if (number == 0)
		{
			name1.setPlayer(number + 1);
		    name2.setPlayer(number + 2);
		    human.setPlayer(number);
		    name1.setCraft(2);
			name1.setLearning(2);
			name1.setIntegrity(2);
			name1.setQuality(0);
			name2.setCraft(1);
			name2.setLearning(3);
			name2.setIntegrity(2);
			name2.setQuality(0);
			human.setCraft(3);
			human.setLearning(0);
			human.setIntegrity(3);
			human.setQuality(0);
		}
		else if(number == 1)
		{
			name1.setPlayer(number - 1);
		    name2.setPlayer(number + 1);
		    human.setPlayer(number);
		    human.setCraft(2);
			human.setLearning(2);
			human.setIntegrity(2);
			human.setQuality(0);
			name1.setCraft(1);
			name1.setLearning(3);
			name1.setIntegrity(2);
			name1.setQuality(0);
			name2.setCraft(3);
			name2.setLearning(0);
			name2.setIntegrity(3);
			name2.setQuality(0);
		}
		else
		{
			name1.setPlayer(number - 1);
		    name2.setPlayer(number - 2);
		    human.setPlayer(number);
		    name2.setCraft(2);
			name2.setLearning(2);
			name2.setIntegrity(2);
			name2.setQuality(0);
			human.setCraft(1);
			human.setLearning(3);
			human.setIntegrity(2);
			human.setQuality(0);
			name1.setCraft(3);
			name1.setLearning(0);
			name1.setIntegrity(3);
			name1.setQuality(0);
		}
		
	    setDefaultCloseOperation(EXIT_ON_CLOSE);
	   
        label.add(name1.getPlayer());
        name1.setPlayerLoc(600, 960); //(location x, location y, width, height)
        
        label.add(name2.getPlayer());
        name2.setPlayerLoc(600, 1000);//(location x, location y, width, height)
        
        label.add(human.getPlayer());
        human.setPlayerLoc(600, 1040); //(location x, location y, width, height)
        
        textField = new Text(name1, name2, human);
        textField.display(deck, discardDeck);//add the player to textPane

        label.setIcon(new javax.swing.ImageIcon("CSULBMap5_1200x1437.png"));
        scroll1.setViewportView(label);
        
        GroupLayout panel1Layout = new GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addComponent(scroll1, GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addComponent(scroll1, GroupLayout.PREFERRED_SIZE, 408, GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        button1.setText("Draw Card");	        
        button1.setMaximumSize(new Dimension(120, 25));
	    button1.setMinimumSize(new Dimension(120, 25));
	    button1.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent evt) {
		    	//new SecondFrame().setVisible(true);
		    	jButton1ActionPerformed(evt);
		    	}
		    });
       
	    button2.setText("Move");
	    button2.setMaximumSize(new Dimension(120, 25));
	    button2.setMinimumSize(new Dimension(120, 25));
	    button2.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent evt) {
		    	jButton2ActionPerformed(evt);
		    	}
		    });

	    button3.setText("Play Card");
	    button3.setMaximumSize(new Dimension(120, 25));
	    button3.setMinimumSize(new Dimension(120, 25));
	    button3.addActionListener(new ActionListener() {
	    public void actionPerformed(ActionEvent evt) {
	    	jButton3ActionPerformed(evt);
	    	}
	    });

	    button2.setEnabled(false);
	    button3.setEnabled(false);
    	name1.updateList(0);
    	name2.updateList(0);
    	human.updateList(0);
    	scroll2.setViewportView(human.getList());

        textArea.setColumns(20);
        textArea.setRows(5);
        textArea.setFont(new Font("Courier New", 0, 14));
        
       
        display.setPlayer(human);
        StringBuilder test = new StringBuilder();
       // test.append(display.displayText(playerHand,80, discardDeck));
        test.append("Human Player is " + human.getName());
        textArea.setText(test.toString());
        scroll3.setViewportView(textArea);

        
        //ArrayList<Card> playCard = Card.add();
        
        //deck.get(50).play(human, 80);
        //cardImg.setIcon(deck.get(50).getCard()); // NOI18N ///adding image to card
        //Card c = show.addCard();
        
        cardImg.setIcon(playerHand.get(0).getCard());
        
        
        cardImg.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent evt) {
                cardMousePressed(evt);
            }
        });
        
       
	    
        GroupLayout panel2Layout = new GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addGroup(panel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(scroll2, GroupLayout.PREFERRED_SIZE, 125, GroupLayout.PREFERRED_SIZE)
                    .addGroup(panel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                        .addComponent(button1, GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
                        .addComponent(button2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(button3, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 123, Short.MAX_VALUE)
                .addComponent(cardImg, GroupLayout.PREFERRED_SIZE, 200, GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(panel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                    .addComponent(textField.getText())
                    .addComponent(scroll3, GroupLayout.DEFAULT_SIZE, 530, Short.MAX_VALUE)))
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addGroup(panel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(panel2Layout.createSequentialGroup()
                        .addComponent(button1)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(button2)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(button3)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(scroll2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel2Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
                        .addGroup(panel2Layout.createSequentialGroup()
                            .addComponent(textField.getText(), GroupLayout.PREFERRED_SIZE, 176, GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(scroll3, GroupLayout.PREFERRED_SIZE, 70, GroupLayout.PREFERRED_SIZE))
                        .addComponent(cardImg, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 258, GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(panel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(20, 20, 20))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(panel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
        
	}
	
	 private void jButton1ActionPerformed(ActionEvent evt) {                                         
	        // TODO add your handling code here:
		//test to see if chip dialog pop up and if textField is edit
		 if(evt.getActionCommand().equals("Draw Card")) {
			 main = new Draw(main);
			 main.action(deck, playerHand,discardDeck);
			 button1.setEnabled(false);
			 button2.setEnabled(true);
			 button3.setEnabled(true);
		 }
		 textField.display(deck, discardDeck);
		
	    }  
	 
	 private void jButton2ActionPerformed(ActionEvent evt) {                                         
	        // TODO add your handling code here:
		 	
		 if(evt.getActionCommand().equalsIgnoreCase("Move")) {
		 		main = new Move(main);
		 		clickCounter = main.action(human, clickCounter);
		 		if(clickCounter >= 3) {
		 			button2.setEnabled(false);
		 			if (evt.getActionCommand().equalsIgnoreCase("Play Card"))
		 			{
		 				clickCounter = 0;
		 				button2.setEnabled(true);
		 			}
		 		}
		 		
		 	 scroll2.setViewportView(human.getList());
			 textField.display(deck, discardDeck);
		 
		 }
	 }  
	
	 private void jButton3ActionPerformed(ActionEvent evt) {                                         
	        // TODO add your handling code here:
		 	if(evt.getActionCommand().equalsIgnoreCase("Play Card")) {
		 		main = new Play(main);
		 		main.action(playerHand, discardDeck, deck, display, textArea, human, name1, name2, count % playerHand.size());
		 		button3.setEnabled(false);
		 		DiscardDisplay trial = new DiscardDisplay(this, true);
		 		count = 0;
		 	}
		 	clickCounter = 0;
		 	if(playerHand.size() == 0) {
		 		button3.setEnabled(false);
		 	}
		 	button1.setEnabled(true);
		 	//textArea.setText("\nHuman player is " + human.getName());
		 	textField.display(deck, discardDeck);
		 	cardImg.setIcon(playerHand.get(0).getCard());
		 	
		 /**/
		 
	    }  
	
	 private void cardMousePressed(MouseEvent evt) {                                  
	        // TODO add your handling code here:
		
		 System.out.println("Mouse clicked on card");
		 count++;
		 int index = count % playerHand.size();
		 cardImg.setIcon(playerHand.get(index).getCard());
		
	    }   
	 
}
