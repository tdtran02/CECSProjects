import java.util.ArrayList;

import javax.swing.*;

public class Card43 extends Card{
	
	private ImageIcon img43;
	
	Card43(){
		img43 = new ImageIcon("images\\cardm43.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//play in la5, prereq = 6 craft, get 5qp
		//fail: go to student parking
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img43 = another;
	}
	
	ImageIcon getCard() {
		return img43;
	}

	
}
