import javax.swing.*;

public class Card43 extends Card{
	
	private ImageIcon img43;
	
	Card43(){
		img43 = new ImageIcon("images\\cardm43.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img43 = another;
	}
	
	ImageIcon getCard() {
		return img43;
	}

	
}
