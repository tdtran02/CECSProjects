import java.util.ArrayList;

import javax.swing.*;

public class Card43 extends Card{
	
	private ImageIcon img43;
	
	Card43(){
		img43 = new ImageIcon("images\\cardm43.png");
	}
	
public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		
		return true;
	}
	
	public String getCardName(boolean success) {
		return "";
	}
	
	ImageIcon getCard() {
		return img43;
	}

	
}
