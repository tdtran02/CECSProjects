import javax.swing.*;

public class Card17 extends Card{
	
	private ImageIcon img17;
	
	Card17(){
		img17 = new ImageIcon("images\\cardm17.png");
	}
	
	public boolean play(Player p, int index){
		if (((p.getX() == 900) && (p.getY() == (960 + index))) && (p.getLearningPoint() >= 3)){
			p.setQuality(p.getQualityPoint() + 5);
		}
		else {
			p.setQuality(p.getQualityPoint() - 3);
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img17 = another;
	}
	
	ImageIcon getCard() {
		return img17;
	}

	
}
