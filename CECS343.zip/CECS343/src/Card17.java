import java.util.ArrayList;

import javax.swing.*;

public class Card17 extends Card{
	
	private ImageIcon img17;
	
	Card17(){
		img17 = new ImageIcon("images\\cardm17.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		if (((p.getX() == 900) && (p.getY() == (960 + index))) && (p.getLearningPoint() >= 3)){
			p.setQuality(p.getQualityPoint() + 5);
			return true;
		}
		else {
			p.setQuality(p.getQualityPoint() - 3);
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Learning Netbeans for 5 Quality Points";
		else
			return "Learning Netbeans failed";
		
	}
	
	ImageIcon getCard() {
		return img17;
	}

	
}
