import javax.swing.*;

public class Card17 extends Card{
	
	private ImageIcon img17;
	
	Card17(){
		img17 = new ImageIcon("images\\cardm17.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img17 = another;
	}
	
	ImageIcon getCard() {
		return img17;
	}

	
}
