import javax.swing.*;

public class Card41 extends Card{
	
	private ImageIcon img41;
	
	Card41(){
		img41 = new ImageIcon("images\\cardm41.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img41 = another;
	}
	
	ImageIcon getCard() {
		return img41;
	}

	
}
