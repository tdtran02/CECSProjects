import java.util.ArrayList;

import javax.swing.*;

public class Card41 extends Card{
	
	private ImageIcon img41;
	
	Card41(){
		img41 = new ImageIcon("images\\cardm41.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//play in ecs 302, 308, or lab, prereq = 7 learing, get 5 qp and 2 card
		//lose 3 qp
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img41 = another;
	}
	
	ImageIcon getCard() {
		return img41;
	}

	
}
