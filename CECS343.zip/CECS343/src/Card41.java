import java.util.ArrayList;

import javax.swing.*;

public class Card41 extends Card{
	
	private ImageIcon img41;
	
	Card41(){
		img41 = new ImageIcon("images\\cardm41.png");
	}
	
public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		
		return true;
	}
	
	public String getCardName(boolean success) {
		return "";
	}
	ImageIcon getCard() {
		return img41;
	}

	
}
