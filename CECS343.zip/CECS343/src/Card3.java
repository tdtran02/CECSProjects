import javax.swing.*;

public class Card3 extends Card{
	
	private ImageIcon img03;
	
	Card3(){
		super();
		img03 = new ImageIcon("images\\cardm03.png");
	}
	
	public boolean play(Player p) {
		if ((p.getX() == 15) && (p.getY() == (1150 + 80))) {
			p.setLearning(p.getLearningPoint() + 1);
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img03 = another;
	}
	
	ImageIcon getCard() {
		return img03;
	}

	
}
