import java.util.ArrayList;

import javax.swing.*;

public class Card51 extends Card{
	
	private ImageIcon img51;
	
	Card51(){
		img51 = new ImageIcon("images\\cardm51.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		
		return true;
	}
	
	public String getCardName(boolean success) {
		return "";
	}
	
	ImageIcon getCard() {
		return img51;
	}

	
}
