import javax.swing.*;

public class Card51 extends Card{
	
	private ImageIcon img51;
	
	Card51(){
		img51 = new ImageIcon("images\\cardm51.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img51 = another;
	}
	
	ImageIcon getCard() {
		return img51;
	}

	
}
