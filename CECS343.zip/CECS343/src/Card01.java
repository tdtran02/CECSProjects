import java.util.ArrayList;

import javax.swing.ImageIcon;

public class Card01 extends Card{
	
	private ImageIcon img01;
	
	Card01(){
		super();
		img01 = new ImageIcon("images\\cardm01.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded) {
		if ((p.getX() == 15) && p.getY() == (1150 + index)) {
			Chip getPoint = new Chip(this, true);
			getPoint.craftDisable();
			getPoint.setVisible(true);
			if (getPoint.getText().equalsIgnoreCase("learning")) {
				p.setLearning(p.getLearningPoint() + 1);
			}
			else if (getPoint.getText().equalsIgnoreCase("integrity")) {
				p.setIntegrity(p.getIntegrityPoint() + 1);
			}
			
		}
		return true;
	}
	
	ImageIcon getCard() {
		return img01;
	}

	
}
