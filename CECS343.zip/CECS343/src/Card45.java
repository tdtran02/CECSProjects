import java.util.ArrayList;

import javax.swing.*;

public class Card45 extends Card{
	
	private ImageIcon img45;
	
	Card45(){
		img45 = new ImageIcon("images\\cardm45.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		
		return true;
	}
	
	public String getCardName(boolean success) {
		return "";
	}
	
	ImageIcon getCard() {
		return img45;
	}

	
}
