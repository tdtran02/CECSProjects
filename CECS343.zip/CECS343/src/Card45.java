import javax.swing.*;

public class Card45 extends Card{
	
	private ImageIcon img45;
	
	Card45(){
		img45 = new ImageIcon("images\\cardm45.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img45 = another;
	}
	
	ImageIcon getCard() {
		return img45;
	}

	
}
