import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextPane;


public class AreaText extends JFrame {
	private Player player;
	
	AreaText(){
		player = new Player();
	}
	
	public String displayText(boolean success, ArrayList<Card> played, int index) {//ArrayList<Card> played, int index, int loc, ArrayList<Card> deck, ArrayList<Card> discard) {
		return (player.getName() + " played " + played.get(index).getCardName(success) + "\n");//(player, loc, played, deck,  discard) + "\n");
	}
	
	public void setPlayer(Player p) {
		player = p;	
	}
}
