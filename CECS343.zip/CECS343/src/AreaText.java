import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextPane;


public class AreaText extends JFrame {
	private Player player;
	//private JTextArea text;
	
	AreaText(){
		player = new Player();
		//text = new JTextArea();
		
	}
	
	public String displayText(ArrayList<Card> played, int loc, ArrayList<Card> discard) {
		//StringBuilder text = new StringBuilder();	
		//System.out.print("The Card is: " + played.get(0).getCardName(player,loc, played, discard));
		return (player.getName() + " " + played.get(0).getCardName(player, loc, played, discard) + "\n");
		//text.append("\nHuman Player is " + player.getName());
		//return text.toString();
		
	}
	public void setPlayer(Player p) {
		player = p;
		
	}
}
