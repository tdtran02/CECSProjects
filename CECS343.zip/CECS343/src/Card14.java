import javax.swing.*;

public class Card14 extends Card{
	
	private ImageIcon img14;
	
	Card14(){
		img14 = new ImageIcon("images\\cardm14.png");
	}
	
	public boolean play(Player p){
		if (((p.getX() == 450) && (p.getY() == 650 + 80)) | ((p.getX() == 600) && p.getY() == (960 + 80))) {
			if (p.getLearningPoint() >= 5) {
				p.setQuality(p.getQualityPoint() + 5);
			}
			else {
				p.setQuality(p.getQualityPoint() - 3);
				//code for lose game card
			}
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img14 = another;
	}
	
	ImageIcon getCard() {
		return img14;
	}

	
}
