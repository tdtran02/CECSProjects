import java.util.ArrayList;

import javax.swing.*;

public class Card14 extends Card{
	
	private ImageIcon img14;
	
	Card14(){
		img14 = new ImageIcon("images\\cardm14.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		if ((((p.getX() == 450) && (p.getY() == 650 + index)) | 
				((p.getX() == 600) && p.getY() == (960 + index))) &&
				(p.getLearningPoint() >= 5)) {
			p.setQuality(p.getQualityPoint() + 5);
			return true;
		}
		else {
			p.setQuality(p.getQualityPoint() - 3);
			if (index == 80) {
			DiscardDisplay throwCard = new DiscardDisplay(this, true);
			throwCard.showDiscard(hand, discard);
			throwCard.setVisible(true);
			}
			else
			{
				if (hand.size() > 1) {
					discard.add(hand.get(1));
					hand.remove(1);
				}
			}
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Math 123 for 5 Quality Points";
		else
			return "Math 123 failed";
		
	}
	
	ImageIcon getCard() {
		return img14;
	}

	
}
