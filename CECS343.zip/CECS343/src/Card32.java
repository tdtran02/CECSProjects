import javax.swing.*;

public class Card32 extends Card{
	
	private ImageIcon img32;
	
	Card32(){
		img32 = new ImageIcon("images\\cardm32.png");
	}
	
	public boolean play(Player p, int index){
		//play any space outside ECS, except forbidden parking, get 1 chip choice
		if (((p.getX() < 150 || p.getX() > 900) && 
				(p.getY() < (650 + index) || p.getY() > (960 + index))) && 
				!(p.getX() == 750 && p.getY() == (350 + index))) {
			
			Chip getPoint = new Chip(this, true);
			getPoint.setVisible(true);
			if (getPoint.getText().equalsIgnoreCase("learning")) {
				p.setLearning(p.getLearningPoint() + 1);
			}
			else if(getPoint.getText().equalsIgnoreCase("integrity")) {
				p.setIntegrity(p.getIntegrityPoint() + 1);
			}
			else if(getPoint.getText().equalsIgnoreCase("craft")) {
				p.setCraft(p.getCraftPoint() + 1);
			}
		}
		return true;
	}
	
	void setCard(ImageIcon another) {
		img32 = another;
	}
	
	ImageIcon getCard() {
		return img32;
	}

	
}
