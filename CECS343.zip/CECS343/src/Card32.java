import javax.swing.*;

public class Card32 extends Card{
	
	private ImageIcon img32;
	
	Card32(){
		img32 = new ImageIcon("images\\cardm32.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img32 = another;
	}
	
	ImageIcon getCard() {
		return img32;
	}

	
}
