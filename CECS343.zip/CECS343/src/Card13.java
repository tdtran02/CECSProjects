import javax.swing.*;

public class Card13 extends Card{
	
	private ImageIcon img13;
	
	Card13(){
		img13 = new ImageIcon("images\\cardm13.png");
	}
	
	public boolean play(Player p){
		if ((p.getX() == 330) && (p.getY() == (200 + 80))) {
			p.setCraft(p.getCraftPoint() + 1);
			p.movePlayer("Lactation Lounge", 80);
			int pAt = p.getRoomList().compareMap("Lactation Lounge");
			p.updateList(pAt);
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img13 = another;
	}
	
	ImageIcon getCard() {
		return img13;
	}

	
}
