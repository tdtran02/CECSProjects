import java.util.ArrayList;

import javax.swing.*;

public class Card13 extends Card{
	
	private ImageIcon img13;
	
	Card13(){
		img13 = new ImageIcon("images\\cardm13.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		if ((p.getX() == 330) && (p.getY() == (200 + index))) {
			p.setCraft(p.getCraftPoint() + 1);
			p.movePlayer("Lactation Lounge", index);
			int pAt = p.getRoomList().compareMap("Lactation Lounge");
			p.updateList(pAt);
			return true;
		}
		else
			return false;
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "The Big Game 1 Craft Chip";
		else
			return "The Big Game failed";
		
	}
	
	ImageIcon getCard() {
		return img13;
	}

	
}
