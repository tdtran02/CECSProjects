import javax.swing.*;

public class Card18 extends Card{
	
	private ImageIcon img18;
	
	Card18(){
		img18 = new ImageIcon("images\\cardm18.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img18 = another;
	}
	
	ImageIcon getCard() {
		return img18;
	}

	
}
