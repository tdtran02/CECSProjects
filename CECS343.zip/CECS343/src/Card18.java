import java.util.ArrayList;

import javax.swing.*;

public class Card18 extends Card{
	
	private ImageIcon img18;
	
	Card18(){
		img18 = new ImageIcon("images\\cardm18.png");
	}
	
	public boolean play(Player p,int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		//conference and 3 integrity, get 5 qp else lose 3 qp
		if (((p.getX() == 900) && (p.getY() == (650 + index))) && (p.getIntegrityPoint() >= 3)){
			p.setQuality(p.getQualityPoint() + 5);
			return true;
		}
		else {
			p.setQuality(p.getQualityPoint() - 3);
			return false;
		}
	}
	public String getCardName(boolean success) {
		if (success)
			return "Choosing a Major for 5 Quality Points";
		else
			return "Choosing a Major failed";	
	}
	
	ImageIcon getCard() {
		return img18;
	}

	
}
