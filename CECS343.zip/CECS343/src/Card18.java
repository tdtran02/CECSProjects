import java.util.ArrayList;

import javax.swing.*;

public class Card18 extends Card{
	
	private ImageIcon img18;
	
	Card18(){
		img18 = new ImageIcon("images\\cardm18.png");
	}
	
	public boolean play(Player p,int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//conference and 3 integrity, get 5 qp else lose 3 qp
		if (((p.getX() == 900) && (p.getY() == (650 + index))) && (p.getIntegrityPoint() >= 3)){
			p.setQuality(p.getQualityPoint() + 5);
		}
		else {
			p.setQuality(p.getQualityPoint() - 3);
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img18 = another;
	}
	
	ImageIcon getCard() {
		return img18;
	}

	
}
