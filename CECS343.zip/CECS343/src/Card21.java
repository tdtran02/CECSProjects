import java.util.ArrayList;

import javax.swing.*;

public class Card21 extends Card{
	
	private ImageIcon img21;
	
	Card21(){
		img21 = new ImageIcon("images\\cardm21.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//George allen field, need 5 craft, get 5qp, else lose 3qp
		if ((p.getX() == 15 && p.getY() == (30 + index)) && p.getCraftPoint() >= 5) {
			p.setQuality(p.getQualityPoint() + 5);
		}
		else {
			p.setQuality(p.getQualityPoint() - 3);
		}
		return true;
	}
	
	void setCard(ImageIcon another) {
		img21 = another;
	}
	
	ImageIcon getCard() {
		return img21;
	}

	
}
