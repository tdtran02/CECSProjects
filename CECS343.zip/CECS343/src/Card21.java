import javax.swing.*;

public class Card21 extends Card{
	
	private ImageIcon img21;
	
	Card21(){
		img21 = new ImageIcon("images\\cardm21.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img21 = another;
	}
	
	ImageIcon getCard() {
		return img21;
	}

	
}
