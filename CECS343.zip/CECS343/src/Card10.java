import java.util.ArrayList;

import javax.swing.*;

public class Card10 extends Card{
	
	private ImageIcon img10;
	
	Card10(){
		super();
		img10 = new ImageIcon("images\\cardm10.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		if ((p.getX() == (450) && p.getY() == (650+index)) | (p.getX() == (600) && p.getY() == (960+index))){
			p.setLearning(p.getLearningPoint() + 1);	
			return true;
		}
		else
			return true;
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "CECS 105 for 1 Learning Chip";
		else
			return "CECS 105 failed";
		
	}
	
	ImageIcon getCard() {
		return img10;
	}

	
}
