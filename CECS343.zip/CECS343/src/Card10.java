import javax.swing.*;

public class Card10 extends Card{
	
	private ImageIcon img10;
	
	Card10(){
		super();
		img10 = new ImageIcon("images\\cardm10.png");
	}
	
	public boolean play(Player p){
		if ((p.getX() == (450) && p.getY() == (650+80)) | (p.getX() == (600) && p.getY() == (960+80))){
			p.setLearning(p.getLearningPoint() + 1);		
		}
		return true;
	}
	
	void setCard(ImageIcon another) {
		img10 = another;
	}
	
	ImageIcon getCard() {
		return img10;
	}

	
}
