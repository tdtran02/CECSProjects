import javax.swing.*;

public class Card46 extends Card{
	
	private ImageIcon img46;
	
	Card46(){
		img46 = new ImageIcon("images\\cardm46.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img46 = another;
	}
	
	ImageIcon getCard() {
		return img46;
	}

	
}
