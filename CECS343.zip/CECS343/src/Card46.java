import java.util.ArrayList;

import javax.swing.*;

public class Card46 extends Card{
	
	private ImageIcon img46;
	
	Card46(){
		img46 = new ImageIcon("images\\cardm46.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded){
		//play in ecs 302, 308, or lab, prereq = 8 learning, 8 craft, 8 integrity, get 5qp
		//fail: lose 2qp, discard 1 card
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img46 = another;
	}
	
	ImageIcon getCard() {
		return img46;
	}

	
}
