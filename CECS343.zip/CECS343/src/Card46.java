import java.util.ArrayList;

import javax.swing.*;

public class Card46 extends Card{
	
	private ImageIcon img46;
	
	Card46(){
		img46 = new ImageIcon("images\\cardm46.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		
		return true;
	}
	
	public String getCardName(boolean success) {
		return "";
	}
	
	ImageIcon getCard() {
		return img46;
	}

	
}
