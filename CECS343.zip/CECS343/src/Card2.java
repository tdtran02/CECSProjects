import javax.swing.*;

public class Card2 extends Card{
	
	private ImageIcon img02;
	
	Card2(){
		super();
		img02 = new ImageIcon("images\\cardm02.png");
	}
	
	public boolean play(Player p) {
		if ((p.getX() == 750) && (p.getY() == (1150 + 80))) {
			p.setCraft(p.getCraftPoint() + 1);
		}
		
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img02 = another;
	}
	
	ImageIcon getCard() {
		return img02;
	}

	
}
