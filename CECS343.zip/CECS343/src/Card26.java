import java.util.ArrayList;

import javax.swing.*;

public class Card26 extends Card{
	
	private ImageIcon img26;
	
	Card26(){
		img26 = new ImageIcon("images\\cardm26.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard){
		//elevators, need 4 learning, get 2 craft. Fail: lose 2qp
		if ((p.getX() == 450 && p.getY() == (960 + index)) && p.getLearningPoint() >= 4) {
			p.setCraft(p.getCraftPoint() + 2);
			return true;
		}
		else {
			p.setQuality(p.getQualityPoint() - 2);
			return false;
		}
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Press the Right Floor for 2 Craft Chips";
		else
			return "Press the Right Floor failed";
		
	}
	
	ImageIcon getCard() {
		return img26;
	}

	
}
