import javax.swing.*;

public class Card26 extends Card{
	
	private ImageIcon img26;
	
	Card26(){
		img26 = new ImageIcon("images\\cardm26.png");
	}
	
	public boolean play(Player p){
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img26 = another;
	}
	
	ImageIcon getCard() {
		return img26;
	}

	
}
