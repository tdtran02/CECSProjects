import java.util.ArrayList;

import javax.swing.ImageIcon;

public class Card07 extends Card{
	
	private ImageIcon img07;
	
	Card07(){
		img07 = new ImageIcon("images\\cardm07.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> humanHand, ArrayList<Card>discarded) {
		if ((p.getX() == 450) && (p.getY() == (960 + index))) {
			p.setIntegrity(p.getIntegrityPoint() + 1);
		}
		
		return true;
	}
	
	void setCard(ImageIcon another) {
		img07 = another;
	}
	
	ImageIcon getCard() {
		return img07;
	}

	
}
