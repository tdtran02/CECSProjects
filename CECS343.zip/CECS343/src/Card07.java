import java.util.ArrayList;

import javax.swing.ImageIcon;

public class Card07 extends Card{
	
	private ImageIcon img07;
	
	Card07(){
		img07 = new ImageIcon("images\\cardm07.png");
	}
	
	public boolean play(Player p, int index, ArrayList<Card> hand, ArrayList<Card> deck, ArrayList<Card> discard) {
		if ((p.getX() == 450) && (p.getY() == (960 + index))) {
			p.setIntegrity(p.getIntegrityPoint() + 1);
			return true;
		}
		else
			return false;
	}
	
	public String getCardName(boolean success) {
		if (success)
			return "Finding the Lab for 1 Integrity Chip";
		else
			return "Finding the Lab failed";
		
	}
	
	ImageIcon getCard() {
		return img07;
	}

	
}
